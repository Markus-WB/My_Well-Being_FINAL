package com.example.mywell_being

data class TestResult(
    val id: Int,
    val result: Int,
    val date: String
)
