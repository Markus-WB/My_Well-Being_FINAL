package com.example.mywell_being

data class MoodResult(
    val id: Int,
    val mood: Int,
    val date: String
)
